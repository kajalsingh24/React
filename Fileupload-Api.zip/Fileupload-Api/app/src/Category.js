import React from 'react'
import axios from 'axios';
import { useState } from 'react'
export default function Category() {
  const [value,setvalue] = useState({
      name : "",
      description:"",
      image : ""
  })   
    const changSet = (e)=> {
      if(e.target.type == "file")
      setvalue({...value, [e.target.name] : e.target.files[0]});
      else
      setvalue({...value, [e.target.name] : e.target.value});
  }
    const  mySaveData = (e)=>{
      e.preventDefault();
      var formData = new FormData();
      formData.append("name",value.name);
      formData.append("description",value.description);
      formData.append("image",value.image);

      var token = JSON.parse(localStorage.getItem("data")).tokens.refreshToken;
      // -----------------Api fetch---------
    axios.post("http://localhost:8002/api/category",formData,{headers: 
    {
       "Content-type":"application/json;charset=UTF-8",                       
       "Authorization" : `Bearer ${token}`
      }}).then(y=> {   
      console.log(y);
    
      })} 
      
  return (
    <>
<div className='container'>
  <div className='form-control bg-warning text-center"'>
    <h4>File upload </h4>
  </div>
      <form  onSubmit={mySaveData}>
        <div className='mb-3 mt-3 form-control'>     

   <label>Name</label>
   <input type="text" name='name' onChange={changSet} className="form-control"/>
   </div>
   <div className='mb-3 mt-3 form-control'>     
<label>description</label>
<input type="text" name='description' onChange={changSet} className="form-control"/>
</div>
   <div className='mb-3 form-control '>
    <div><label>Upload image</label></div>
  <input type="file" name="image" onChange={changSet} className="btn btn-warning" />
  </div>
<div className='mt-3'>
  <input type="button"  value="save"  class="btn btn-success" onClick={mySaveData}/>
  </div>
      </form>
      </div>
  

    </>
  )
}
