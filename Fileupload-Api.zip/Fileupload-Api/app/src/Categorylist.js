import React from 'react'
import { useEffect, useState } from 'react';
import axios from 'axios';
export default function Categorylist() {
const [listvalue,setlistvalue] = useState([])
useEffect(()=>
{
  axios.get("http://localhost:8002/api/category?select=name%2C%20image").then
  ((carddata=>
  {
           console.log(carddata)                 
          setlistvalue(carddata.data.categories);        
  }))
},[])
  return (
<>
<div className='container mainclass'>
 <div className='row'>
  {
   listvalue.map((x)=>
   {
return(
<div className='col-xl-4 col-lg-4 col-sm-6 col-md-6 mb-4'>
<div className="card" style={{width: "18rem"}}>
<img src={x.image}className="card-img-top" alt="..."/>
  <div class="card-body">
    <h5 class="card-title">{x._id}</h5>
    <h3 class="card-text">{x.name}</h3>
    <a href="#" class="btn btn-primary">Add to cart</a>
  </div>
</div>
</div>                
   )})                           
  }                            
</div>
</div>
</>
  )
}
